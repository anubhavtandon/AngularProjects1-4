

export class Product{
customerFullName : string;
customerEmailId:string;
password:string;
customerPhone:number;
}