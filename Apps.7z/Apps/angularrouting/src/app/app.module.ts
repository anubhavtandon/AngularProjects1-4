﻿import { NgModule, Component }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { HttpClientModule } from '@angular/common/http';
import {Routes,RouterModule} from '@angular/router';
import {AddProductComponent} from './app.addproductcomponent';
import {FormsModule} from '@angular/forms';
import {ShowProductComponent} from './app.showcomponent';


const router:Routes=[
    {path:'add', component:AddProductComponent},
    {path:'show', component:ShowProductComponent}


]

@NgModule({
    imports: [
        BrowserModule,FormsModule,HttpClientModule,RouterModule.forRoot(router)
        
    ],
    declarations: [
        AppComponent, AddProductComponent,ShowProductComponent
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }