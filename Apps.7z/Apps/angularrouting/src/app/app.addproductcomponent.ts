import { Component,OnInit } from "@angular/core";
import {Product} from './Product';
import{ProductService} from './app.productService';
import {AppModule} from './app.module';

@Component({
    selector:'add-app',
    templateUrl:'add.product.html'
})
export class AddProductComponent{
    constructor(private prodservice: ProductService){}
    prod:any={};

    addProduct():any{
        this.prodservice.addProduct(this.prod).subscribe((data)=>console.log(data));
       // this.router.navigate(['show']);

    }
}