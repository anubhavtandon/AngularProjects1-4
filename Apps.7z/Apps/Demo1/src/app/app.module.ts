﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import {AddProduct} from './app.addproductcomponent';
import { ShowProduct } from './app.showproductcomponent';

@NgModule({
    imports: [
        BrowserModule
        
    ],
    declarations: [
        AppComponent,AddProduct,ShowProduct
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }