import{ Component } from '@angular/core';
@Component({
    selector:'add-prod',
    templateUrl:'add.product.html'
})
export class AddProduct{
}