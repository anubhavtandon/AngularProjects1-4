﻿
import {Component,OnInit} from '@angular/core';
import { ProductService } from './app.productService';
@Component({
    selector: 'app',
    templateUrl: 'app.component.html'
})

export class AppComponent implements OnInit {
constructor(private prodservice:ProductService){}

prod:any={};
prodAll:any[];
ngOnInit(){
this.prodservice.getAllProduct().subscribe((data:any)=>this.prodAll=data);
}


addProduct():any{
  // alert(this.prod.customerFullName);
  this.prodservice.addProduct(this.prod).subscribe();
}
 }