import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable({
    providedIn:'root'
})
export class ProductService{
    constructor(private httpdata:HttpClient){}
    getAllProduct(){
        return this.httpdata.get("http://localhost:1231/getAllCustomerDetails");
    }
addProduct(data:any){
    console.log(data.customerEmailId);
    let input = new FormData();
    input.append("customerEmailId",data.customerEmailId);
    input.append("customerFullName",data.customerFullName);
    input.append("customerPhone",data.customerPhone);
    input.append("password",data.password);
    input.append("customerAddress.city",data.customerAddresscity);
    input.append("customerAddress.zipcode",data.customerAddresszip);
    input.append("customerAddress.country",data.customerAddresscountry);
    input.append("customerAddress.street",data.customerAddressstreet);
    input.append("customerAddress.area",data.customerAddressarea);
   return this.httpdata.post("http://localhost:1231/addCustomer",input);
}
}