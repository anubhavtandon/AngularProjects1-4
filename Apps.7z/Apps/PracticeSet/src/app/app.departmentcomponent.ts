import {Component} from '@angular/core';
@Component({
    selector:'department',
    templateUrl:'department.html'
})
export class DepartmentComponent{
    departmentId:number=1001;
    departmentName:string="ANUBHAV";
    departmentSalary:number=10000.55;
    departmentOnline:boolean=true;
    getAllDepartmentDetails():any{
       
    }

}