import {Component} from '@angular/core';
import {Employee} from './Employee';
@Component({
    selector:'employee',
    templateUrl:'employee.html'
})
export class EmployeeComponent{
   emp:any={};


   empAll:Employee[]=[
       {empId:1001,empName:"ANubhav",empOnline:true,empSalary:998.09},
       {empId:1003,empName:"Tandon",empOnline:true,empSalary:9966.9},
       {empId:1002,empName:"lol",empOnline:true,empSalary:9966.9},
       {empId:1004,empName:"okk",empOnline:true,empSalary:9966.9},
       {empId:1009,empName:"lmao",empOnline:true,empSalary:9966.9}
   ];

    getAllEmployee():any{
        alert("Hey YOU");        
    }
 addEmployee():any{
   //  alert(this.emp.empId+""+this.emp.empName+""+this.emp.empSalary+""+this.emp.empOnline);
 this.empAll.push(this.emp);
 this.emp={};

}

 deleteEmployee(i:number):any{
     this.empAll.splice(i,1);
 }
 

}