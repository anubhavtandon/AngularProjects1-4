
//This is for connectivity with angular and spring-boot

import{Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
@Injectable({
    providedIn:'root'

})
export class ProductService{
constructor(private httpdata:Http:HttpClient){}
getAllProduct(){
    this.httpdata.get('localhost:1231/getCustomer?email=aaa')
}

}